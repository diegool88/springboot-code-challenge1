package com.capmation.challenge1;

import java.util.Date;

public record TransferenceRecord(Long destinationId, Double amount, Date dateTime) {

}
