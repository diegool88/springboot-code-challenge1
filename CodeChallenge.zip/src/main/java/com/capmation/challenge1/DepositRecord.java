package com.capmation.challenge1;

import java.util.Date;

public record DepositRecord(Long id, Double amount, Date dateTime) {

}
