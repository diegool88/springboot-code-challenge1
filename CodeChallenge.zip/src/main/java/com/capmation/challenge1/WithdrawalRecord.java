package com.capmation.challenge1;

import java.util.Date;

public record WithdrawalRecord(Long id, Double amount, Date dateTime) {

}
